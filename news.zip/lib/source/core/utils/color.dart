import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

class ColorsNews{
  static Color primary=Colors.blue;
  static Color hint=Colors.grey;
}