class Fonts{
  static const String appName="News Tody";
  static const String fontFamily='assets/images/';
}