
class assets{
  static String photoNAme='assets/images/       ';
}